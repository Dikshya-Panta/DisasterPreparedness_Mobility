'''For downloading the data'''
# Import requests library to call API endpoint
# import requests
#
# # Set the API key and API endpoint variables
# API_KEY = "M601EsrN.BwG0ba8Y2UT8lzbdi3IeYTs2D7ANh4iuu0SuzptNVoU0xzXLdwkwLaIH"
# PRODUCT_API_PATH = "https://app.deweydata.io/external-api/v3/products/364d4770-9e54-45fc-9298-d669c0dff220/files"
#
# # Set the output folder where the files will be saved
# output_folder = r"D:\gulfshores_homepanel"
#
# # Initialize the page number and download count
# page = 1
# download_count = 0
#
# while True:
#     # Get results from the API endpoint using the API key for authentication
#     results = requests.get(url=PRODUCT_API_PATH,
#                            params={'page': page,
#                                    'partition_key_after': '2020-08-01',  # Start date
#                                    'partition_key_before': '2020-11-15'},  # End date
#                            headers={'X-API-KEY': API_KEY,
#                                     'accept': 'application/json'
#                                     })
#
#     response_json = results.json()
#
#     # Loop through the download links and save them to the computer
#     for link_data in response_json.get('download_links', []):
#         # Create a file name for each link
#         if response_json.get('partition_column'):
#             file_name = f"{output_folder}\\file-{download_count + 1}-{response_json['partition_column']}-{link_data['partition_key']}.csv.gz"
#         else:
#             file_name = f"{output_folder}\\file-{download_count + 1}.csv.gz"
#
#         print(f'Downloading file {file_name}...')
#
#         # Download and save the data
#         data = requests.get(link_data['link'])
#         with open(file_name, 'wb') as file:
#             file.write(data.content)
#         download_count += 1
#
#     # Only continue if there are more result pages to process
#     total_pages = response_json.get('total_pages', 0)
#     if page >= total_pages:
#         break
#     page += 1
#
# print(f"Successfully downloaded {download_count} files.")



'''The files were presented in gz folder, extracting those files'''
# import gzip
# import shutil
# import os
#
# def extract_gz(gz_file_path, output_directory):
#     if not os.path.exists(output_directory):
#         os.makedirs(output_directory)
#     file_name = os.path.basename(gz_file_path)
#     extracted_file_path = os.path.join(output_directory, file_name.replace('.gz', ''))
#     with gzip.open(gz_file_path, 'rb') as f_in:
#         with open(extracted_file_path, 'wb') as f_out:
#             shutil.copyfileobj(f_in, f_out)
#     print(f"File extracted to: {extracted_file_path}")
#
# def extract_all_gz_files(input_directory, output_directory):
#     for file in os.listdir(input_directory):
#         if file.endswith('.gz'):
#             gz_file_path = os.path.join(input_directory, file)
#             extract_gz(gz_file_path, output_directory)
#
# input_directory = r'E:\file'
# output_directory = r'E:\gulf_shores'
#
# extract_all_gz_files(input_directory, output_directory)




'''The data downloded was for a specific time period ~ a year and for the whole of US. However, we only need data for a specific location, for e.g. Breathitt county 
county for flood (2022), Lee county for Hurricane Ian (2022) and Baldwin county for Hurricane sally 2020.

 Selecting only the study area florida'''

# Saves files in a single parent directory and sub directories inside it.

# import os
# import pandas as pd
#
# output_directory = 'E:\\Dikshya\\Hurricane_Ian_Florida\\7-April\\filtered_hurricane'
# os.makedirs(output_directory, exist_ok=True)
#
# def filter_rows_by_fips(df, column_name='POI_CBG', fips_code='12071'):
#     # Filters rows in a DataFrame based on the FIPS code in a specified column.
#
#     df[column_name] = df[column_name].astype(str)
#     mask = df[column_name].str.startswith(fips_code)
#     filtered_df = df[mask]
#     return filtered_df
#
# directory_path = 'E:\\Dikshya\\Flood\\PR\\Prep_R'
#
# # Specify data types for columns that previously had mixed types
# dtype_spec = {
#     2: str,
#     4: str,
#     7: str,
#     17: str,
#     18: str
# }
#
# # Loop through each file in the directory
# for filename in os.listdir(directory_path):
#     # Identify the start of the date string within the filename
#     date_start_idx = filename.find('DATE_RANGE_START-') + len('DATE_RANGE_START-')
#     if date_start_idx > len('DATE_RANGE_START-') - 1:  # Check if 'DATE_RANGE_START-' was found
#         # Extract the month part of the date from the filename
#         month = filename[date_start_idx+5:date_start_idx+7]
#         # Check if the month is September or October
#         if month in ('09', '10'):
#             file_path = os.path.join(directory_path, filename)
#             # Read the CSV file, using the specified data types
#             df = pd.read_csv(file_path, dtype=dtype_spec)
#             # Apply the filter function
#             filtered_df = filter_rows_by_fips(df)
#             # Save the filtered DataFrame to a new CSV file in the specified output directory
#             filtered_df.to_csv(os.path.join(output_directory, filename), index=False)
#             print(f'Processed file: {filename}')
#         else:
#             print(f'Skipped file (not in target months): {filename}')
#     else:
#         print(f'Skipped file (invalid format): {filename}')





'''# selecting the study area for Breathitt county, kentucky.'''
# import os
# import pandas as pd
#
# output_directory = 'E:\\Dikshya\\Flood\\location'
# os.makedirs(output_directory, exist_ok=True)
#
# def filter_rows_by_fips(df, column_name='POI_CBG', fips_code='21025'):
#     df[column_name] = df[column_name].astype(str)
#     mask = df[column_name].str.startswith(fips_code)
#     filtered_df = df[mask]
#     return filtered_df
#
# directory_path = 'E:\\Dikshya\\Flood\\Prep_R'
#
# dtype_spec = {
#     2: str,
#     4: str,
#     7: str,
#     17: str,
#     18: str
# }
#
# for filename in os.listdir(directory_path):
#     if filename.endswith('.csv'):
#         # Check if the filename contains '-08-' or '-09-' indicating August or September
#         if '-08-' in filename or '-09-' in filename:
#             file_path = os.path.join(directory_path, filename)
#             df = pd.read_csv(file_path, dtype=dtype_spec)
#
#             # Apply the filter function
#             filtered_df = filter_rows_by_fips(df)
#
#             # Save the filtered DataFrame to a new CSV file in the specified output directory
#             filtered_df.to_csv(os.path.join(output_directory, filename), index=False)


'''selecting the study area for Baldwin County, Alabama.'''
# import os
# import pandas as pd
#
# output_directory = 'E:\\2020-extracted'
# os.makedirs(output_directory, exist_ok=True)
#
# def filter_rows_by_fips(df, column_name='poi_cbg', fips_code='01003'):
#     df[column_name] = df[column_name].astype(str)
#     mask = df[column_name].str.startswith(fips_code)
#     filtered_df = df[mask]
#     return filtered_df
#
# parent_directory = 'E:\\Hurricane_Sally'
#
# # Specify data types for columns that previously had mixed types
# dtype_spec = {
#     2: str,
#     4: str,
#     7: str,
#     17: str,
#     18: str
# }
#
# # Loop through each subdirectory in the parent directory
# for subdirectory in os.listdir(parent_directory):
#     subdirectory_path = os.path.join(parent_directory, subdirectory)
#
#     # Check if the current item is a directory
#     if os.path.isdir(subdirectory_path):
#         # Create corresponding subdirectory in the output directory
#         output_subdirectory = os.path.join(output_directory, subdirectory)
#         os.makedirs(output_subdirectory, exist_ok=True)
#
#         # Loop through each file in the subdirectory
#         for filename in os.listdir(subdirectory_path):
#             file_path = os.path.join(subdirectory_path, filename)
#
#             # Check if the current item is a file
#             if os.path.isfile(file_path):
#                 try:
#                     # Read the CSV file, using the specified data types
#                     df = pd.read_csv(file_path, dtype=dtype_spec)
#                     # Apply the filter function
#                     filtered_df = filter_rows_by_fips(df)
#                     # Save the filtered DataFrame to a new CSV file in the corresponding output subdirectory
#                     output_file_path = os.path.join(output_subdirectory, filename)
#                     filtered_df.to_csv(output_file_path, index=False)
#                     print(f'Processed file: {file_path}')
#                 except PermissionError:
#                     print(f'Permission denied: {file_path}')
#                 except Exception as e:
#                     print(f'An error occurred while processing {file_path}: {e}')
#             else:
#                 print(f'Skipped non-file item: {file_path}')
#     else:
#         print(f'Skipped non-directory item: {subdirectory_path}')



'''There are multiple csv files for each week (around 500). With this code, I merge all the files for 1 week. Hence, each csv file represents a week. '''
# #  A separate folder for each week is created and all the csv files that belong to a certain week is kept in that folder
# import os
# import shutil
#
# input_dir = r'E:\Dikshya\Flood\Preparation\Naics_filtered\Week_1'
# output_dir = r'E:\Dikshya\Flood\Preparation\Naics_weekly'
#
# # Ensure the output directory exists
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#
# # List all CSV files in the input directory
# csv_files = [f for f in os.listdir(input_dir) if f.endswith('.csv')]
#
# # Process each file
# for file_name in csv_files:
#     # Extract the week identifier from the file name
#     week_identifier = file_name.split('-')[-2] + '-' + file_name.split('-')[-1].replace('.csv', '')
#
#     # Create a directory for the week if it doesn't exist
#     week_dir = os.path.join(output_dir, week_identifier)
#     if not os.path.exists(week_dir):
#         os.makedirs(week_dir)
#
#     # Move the file to the week's directory
#     shutil.move(os.path.join(input_dir, file_name), os.path.join(week_dir, file_name))
#
# print("Files have been organized by week.")




'''The data contains multiple columns that are not necessary and hence selecting only those columns that are needed.'''
# if it has parent directories
# import os
# import pandas as pd
#
# # Directory containing the CSV files
# data_directory = r'E:\flood\13May\no_months'
#
# # Output directory
# output_directory = r'E:\flood\13May\columns'
#
# # Ensure the output directory exists
# os.makedirs(output_directory, exist_ok=True)
#
# # Specify the columns to keep
# columns_to_keep = ['top_category', 'latitude', 'longitude',
#                    'raw_visit_counts', 'raw_visitor_counts', 'poi_cbg',
#                    'visitor_home_cbgs', 'date_range_start']
#
# # Loop through the files in the data directory
# for filename in os.listdir(data_directory):
#     if filename.endswith('.csv'):
#         filepath = os.path.join(data_directory, filename)
#         # Read and filter the CSV file
#         df = pd.read_csv(filepath, usecols=columns_to_keep)
#
#         # Optional: Remove columns that are completely empty or contain all NA values before appending
#         df.dropna(axis=1, how='all', inplace=True)
#
#         # Define the output path keeping the original filename
#         output_path = os.path.join(output_directory, filename)
#         df.to_csv(output_path, index=False)
#
#         print(f"CSV file {filename} has been processed and saved successfully to {output_path}.")





'''I have noticed that the number of raw_visit_counts , visitor_home_cbgs and even the visitor_home_cbgs and the number of visitors visiting from the home_cbgs to 
placekey are repeated, even when the placekey, and location is different. Hence, I deleted some rows using the code here'''
# deleting duplicate rows
# import os
# import pandas as pd
# import logging
#
# # Setup logging
# logging.basicConfig(level=logging.INFO, filename='process_log.txt', filemode='w',
#                     format='%(asctime)s - %(levelname)s - %(message)s')
#
# # Define the input and output directories
# input_dir = r'E:\flood\13May\columns'
# output_dir = r'E:\flood\13May\duplicates_deleted'
#
# # Ensure the output directory exists
# os.makedirs(output_dir, exist_ok=True)
#
# # Define the columns to check for duplicates
# duplicate_columns = ['raw_visit_counts', 'raw_visitor_counts', 'poi_cbg', 'visitor_home_cbgs']
# logging.info("Columns used for checking duplicates: %s", duplicate_columns)
#
# # Process each file in the input directory
# for filename in os.listdir(input_dir):
#     if filename.endswith('.csv'):
#         try:
#             # Read the CSV file
#             file_path = os.path.join(input_dir, filename)
#             df = pd.read_csv(file_path)
#
#             # Drop duplicate rows based on the specified columns
#             initial_row_count = df.shape[0]
#             df_cleaned = df.drop_duplicates(subset=duplicate_columns)
#             final_row_count = df_cleaned.shape[0]
#             rows_deleted = initial_row_count - final_row_count
#
#             # Write the cleaned dataframe to a new file in the output directory
#             output_path = os.path.join(output_dir, filename)
#             df_cleaned.to_csv(output_path, index=False)
#
#             # Log and print the number of deleted rows
#             log_message = f"Processed {filename}: Removed {rows_deleted} duplicate rows."
#             logging.info(log_message)
#             print(log_message)
#         except Exception as e:
#             error_message = f"Failed to process {filename} due to {e}"
#             logging.error(error_message)
#             print(error_message)
#
# logging.info("All files have been processed.")
# print("All files have been processed.")




''' exploding the visitor column'''
# import pandas as pd
# import os
#
# # Define the directory containing the CSV files
# input_dir = r'E:\flood\13May\duplicates_deleted'
# output_dir = r'E:\flood\13May\visitor_exposed'
#
# # Make sure the output directory exists, create if it does not
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#
# # Loop through each file in the directory
# for filename in os.listdir(input_dir):
#     if filename.endswith('.csv'):
#         # Construct the full file path
#         file_path = os.path.join(input_dir, filename)
#
#         # Load the CSV file
#         df = pd.read_csv(file_path)
#
#         # Split the 'visitor_home_cbgs' column into a list of values
#         df['visitor_home_cbgs'] = df['visitor_home_cbgs'].str.split(',')
#
#         # Explode the 'visitor_home_cbgs' column to have each value in a separate row
#         df_exploded = df.explode('visitor_home_cbgs')
#
#         # Save the resulting DataFrame to a new CSV file
#         output_file_path = os.path.join(output_dir, filename)
#         df_exploded.to_csv(output_file_path, index=False)
#
# print("All files have been processed and saved.")




'''Making a new column called count for tracking the number of visitors from a specific POI to another.'''
# import pandas as pd
# import os

# Define the directory containing the CSV files
# input_dir = r'E:\flood\13May\visitor_exposed'
# output_dir = r'E:\flood\13May\count'
#
# # Make sure the output directory exists, create if it does not
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#
# def extract_count(cbgs_str):
#     if isinstance(cbgs_str, str):
#         # Ensure the string is a valid JSON-like object by checking its start and end
#         if not cbgs_str.startswith('{'):
#             cbgs_str = '{' + cbgs_str
#         if not cbgs_str.endswith('}'):
#             cbgs_str += '}'
#         try:
#             # Parse the string as dictionary
#             cbgs_dict = eval(cbgs_str)
#             return sum(cbgs_dict.values())
#         except (SyntaxError, ValueError):
#             print(f"Error parsing string: {cbgs_str}")
#             return 0
#     else:
#         return 0
#
# # Loop through each file in the directory
# for filename in os.listdir(input_dir):
#     if filename.endswith('.csv'):
#         # Construct the full file path
#         file_path = os.path.join(input_dir, filename)
#
#         # Load the CSV file
#         df = pd.read_csv(file_path)
#
#         # Apply the extract_count function to the 'visitor_home_cbgs' column to create the 'count' column
#         df['count'] = df['visitor_home_cbgs'].apply(extract_count)
#
#         # Save the resulting DataFrame to a new CSV file
#         output_file_path = os.path.join(output_dir, filename)
#         df.to_csv(output_file_path, index=False)
#
# print("All files have been processed and saved.")





'''cleaning the origin column; removing any symbols present'''
# import pandas as pd
# import os
#
# # Define the directory containing the CSV files
# input_dir = r'E:\flood\13May\count'
# output_dir = r'E:\flood\13May\origin_cleaned'
#
# # Make sure the output directory exists, create if it does not
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#
#
# def clean_visitor_home_cbgs(cbgs_str):
#     if isinstance(cbgs_str, str):
#         # Remove unwanted characters and extract the key before the colon
#         cleaned = cbgs_str.replace('{', '').replace('}', '').replace('"', '')
#         # Split by colon and take the first part (the key)
#         key = cleaned.split(':')[0] if ':' in cleaned else cleaned
#         return key
#     return ""  # Return an empty string if the input isn't a string
#
#
# # Loop through each file in the directory
# for filename in os.listdir(input_dir):
#     if filename.endswith('.csv'):
#         # Construct the full file path
#         file_path = os.path.join(input_dir, filename)
#
#         # Load the CSV file
#         df = pd.read_csv(file_path)
#
#         # Apply the clean_visitor_home_cbgs function to modify the 'visitor_home_cbgs' column
#         df['visitor_home_cbgs'] = df['visitor_home_cbgs'].apply(clean_visitor_home_cbgs)
#
#         # Save the resulting DataFrame to a new CSV file
#         output_file_path = os.path.join(output_dir, filename)
#         df.to_csv(output_file_path, index=False)
#
# print("All files have been processed and saved.")




'''keeping only those rows that contains visit values coming from the same county, exclusing values that are from or to any cbg outside the study county. 
repeat this for all the 3 study areas'''
# import os
# import pandas as pd
#
# # Directory containing the CSV files
# input_directory = r'E:\flood\13May\origin_cleaned'
# output_directory = r'E:\flood\13May\origin_filtered'
#
# # Ensure the output directory exists
# os.makedirs(output_directory, exist_ok=True)
#
# # Loop through each file in the directory
# for filename in os.listdir(input_directory):
#     if filename.endswith('.csv'):
#         filepath = os.path.join(input_directory, filename)
#         # Read the CSV file
#         df = pd.read_csv(filepath)
#
#         # Check if 'visitor_home_cbgs' column exists
#         if 'visitor_home_cbgs' in df.columns:
#             # Remove rows where 'visitor_home_cbgs' is NaN or empty
#             df = df.dropna(subset=['visitor_home_cbgs'])
#             df = df[df['visitor_home_cbgs'].astype(str).str.strip() != ""]
#
#             # Filter the dataframe for rows starting with '01003' or '1003'
#             df_filtered = df[df['visitor_home_cbgs'].astype(str).str.startswith(('01003 or 1003'))]
#
#             # Save the filtered dataframe to a new file in the output directory
#             output_filepath = os.path.join(output_directory, filename)
#             df_filtered.to_csv(output_filepath, index=False)
#
#             print(f"Processed and saved filtered data for {filename} to {output_filepath}.")
#         else:
#             print(f"'visitor_home_cbgs' column not found in {filename}.")







'''preparing population data'''

# # separating the geoid in population csv file and making a new column
# import pandas as pd
#
# # Path to your input file
# input_file_path = r'E:\gulf_shores\ACSDT5Y2020\ACSDT5Y2020.B01003-Data.csv'
# # Path to your output file
# output_file_path = r'E:\gulf_shores\ACSDT5Y2020\popn-Data.csv'
#
# # Load the CSV file
# df = pd.read_csv(input_file_path)
#
# # Split the "GEO_ID" column into two parts: The prefix "1500000US" and the rest
# df[['GEO_ID', 'ORIGIN_BG']] = df['GEO_ID'].str.extract(r'(1500000US)(.*)')
#
# # Save the modified DataFrame to a new CSV file
# df.to_csv(output_file_path, index=False)
#
# print("File has been successfully modified and saved.")


# # # to clean the population data
# import pandas as pd
#
# # Replace this with the actual path to your CSV file
# file_path = r'E:\gulf_shores\ACSDT5Y2019\popn-Data.csv'
#
# # Load the CSV file
# df = pd.read_csv(file_path)
#
# # Remove the specified columns
# df.drop(['GEO_ID', 'NAME', 'Unnamed: 4'], axis=1, inplace=True, errors='ignore')
#
# # Rename the specified columns
# df.rename(columns={'B01003_001E': 'Population_total', 'B01003_001M': 'Error_Margin'}, inplace=True)
#
# # Define the path for the cleaned file
# cleaned_file_path = file_path.rsplit("\\", 1)[0] + '\\cleaned.csv'
#
# # Save the modified DataFrame to the new file
# df.to_csv(cleaned_file_path, index=False)
#
# print(f"File has been successfully cleaned and saved as {cleaned_file_path}.")


# # # removing the second row of the csv file popln as we are preparing for merging
# import csv
# # Specify the path to your CSV file
# input_filepath = 'E:\\gulf_shores\\ACSDT5Y2020\\cleaned.csv'  # Make sure the file extension is correct
# output_filepath = 'E:\\gulf_shores\\ACSDT5Y2020\\cleaned_15.csv'  # Temporary file to store results
#
# # Read the original file and write the desired contents to a new file, skipping the second row
# with open(input_filepath, 'r', newline='') as infile, open(output_filepath, 'w', newline='') as outfile:
#     reader = csv.reader(infile)
#     writer = csv.writer(outfile)
#
#     for i, row in enumerate(reader):
#         if i != 1:  # Skip the second row (index 1)
#             writer.writerow(row)
#
# # Now, replace the original file with the new file if you want to overwrite it




'''merging population file with multiple mobility files'''
# import pandas as pd
# import os
#
# # Path to the folder containing the initial CSVs
# folder_path = r'E:\flood\13May\homepanel_mobility'
# # Path to the CSV that needs to be merged with each file in the folder
# file2_path = r'E:\flood\Accesories\Flood\popln\cleaned.csv'
# # Define the output folder path
# output_folder_path = r'E:\flood\13May\homepanel_mobility_popln'
#
# # Ensure the output folder exists, create if it does not
# os.makedirs(output_folder_path, exist_ok=True)
#
# # Load the additional data from file2_df
# file2_df = pd.read_csv(file2_path)
#
# # Iterate over each CSV file in the folder
# for filename in os.listdir(folder_path):
#     if filename.endswith('.csv'):
#         # Construct the full file path for the current CSV
#         file1_path = os.path.join(folder_path, filename)
#         # Load the current CSV file
#         file1_df = pd.read_csv(file1_path)
#         # Merge the current CSV with the additional data using the specified column names
#         merged_df = pd.merge(file1_df, file2_df, left_on='visitor_home_cbgs', right_on='ORIGIN_BG', how='inner')
#         # Construct the output file path using the original filename
#         output_file_path = os.path.join(output_folder_path, filename)
#         # Save the merged DataFrame to the specified output file
#         merged_df.to_csv(output_file_path, index=False)
#         print(f'Merged CSV file has been saved to: {output_file_path}')






'''Preparing the homepanel data'''
# selecting only the study area
# import os
# import pandas as pd
#
# def filter_rows_by_fips(df, column_name='CENSUS_BLOCK_GROUP', fips_codes=['10030', '01003']):
#     try:
#         df[column_name] = df[column_name].astype(str)  # Ensure the column is string type
#         # Create a mask that checks if any of the FIPS codes are in the column
#         mask = df[column_name].apply(lambda x: any(x.startswith(code) for code in fips_codes))
#         filtered_df = df[mask]
#         return filtered_df
#     except KeyError:
#         print(f"Error: Column '{column_name}' not found in DataFrame.")
#         return None  # Return None if column is not found
#     except Exception as e:
#         print(f"An error occurred: {e}")
#         return None
#
# # Path to the directory containing your CSV files
# directory_path = r'D:\Sally_latest\homepanel\extracted'
# # Output directory path
# output_directory = r'D:\Sally_latest\homepanel\homepanel_filtered'
#
# # Create the output directory if it does not exist
# os.makedirs(output_directory, exist_ok=True)
#
# # Loop through each file in the directory
# for filename in os.listdir(directory_path):
#     if filename.endswith('.csv'):
#         file_path = os.path.join(directory_path, filename)
#         try:
#             df = pd.read_csv(file_path)
#             # Apply the filter function
#             filtered_df = filter_rows_by_fips(df)
#             if filtered_df is not None and not filtered_df.empty:
#                 # Construct the output file path
#                 output_file_path = os.path.join(output_directory, filename)
#                 # Save the filtered DataFrame to a new CSV file
#                 filtered_df.to_csv(output_file_path, index=False)
#                 print(f"Filtered data written to {output_file_path}")
#             else:
#                 print(f"No data matching FIPS code in {filename}")
#         except pd.errors.EmptyDataError:
#             print(f"No data in {filename}")
#         except Exception as e:
#             print(f"Failed to process {filename}: {e}")




# Deletes the unnecessary columns from the home panel summary data
# import pandas as pd
# import os
#
# # Paths to the input and output folders
# input_folder_path = r'D:\Sally_latest\homepanel\homepanel_filtered'
# output_folder_path = r'D:\Sally_latest\homepanel\columns'
#
# # Ensure the output folder exists, create if it does not
# os.makedirs(output_folder_path, exist_ok=True)
#
# # Iterate over each file in the input folder
# for filename in os.listdir(input_folder_path):
#     if filename.endswith('.csv'):
#         # Construct the full path to the input file
#         input_file_path = os.path.join(input_folder_path, filename)
#
#         # Load the CSV file into a DataFrame
#         df = pd.read_csv(input_file_path)
#
#         # Delete the columns 'ISO_COUNTRY_CODE' and 'REGION' if they exist
#         df.drop(columns=['ISO_COUNTRY_CODE', 'REGION'], errors='ignore', inplace=True)
#
#         # Rename the column 'CENSUS_BLOCK_GROUP' to 'ORIGIN_BG' if it exists
#         if 'CENSUS_BLOCK_GROUP' in df.columns:
#             df.rename(columns={'CENSUS_BLOCK_GROUP': 'ORIGIN_BG'}, inplace=True)
#
#         # Construct the full path to the output file
#         output_file_path = os.path.join(output_folder_path, filename)
#
#         # Save the modified DataFrame to the output folder
#         df.to_csv(output_file_path, index=False)
#
#         print(f'Processed and saved: {filename} to the output folder.')





# Separating homepanel data into each week

# import pandas as pd
# import os
# from datetime import datetime, timedelta
# #
# # # Adjust these paths as necessary
# input_folder_path = r'D:\Sally_latest\homepanel\homepanel_filtered'
# output_folder_path = r'D:\Sally_latest\homepanel\weekly'
# #
# # Define the start date for week numbering
# week_start_date = datetime.strptime("2020-03-01", "%Y-%m-%d")
#
# def split_csv_weekly(input_file_path, output_folder_path):
#     # Load the CSV file
#     df = pd.read_csv(input_file_path)
#
#     # Convert date columns to datetime
#     df['DATE_RANGE_START'] = pd.to_datetime(df['DATE_RANGE_START'])
#     df['DATE_RANGE_END'] = pd.to_datetime(df['DATE_RANGE_END'])
#
#     # Exclude data before the week_start_date
#     df = df[df['DATE_RANGE_START'] >= week_start_date]
#
#     if df.empty:
#         print(f"No data after the start date in {input_file_path}. Skipping.")
#         return
#
#     # Calculate custom week numbers based on the start date
#     df['WEEK'] = ((df['DATE_RANGE_START'] - week_start_date).dt.days / 7).astype(int) + 1
#
#     # Split the data by custom week number and save separate files
#     for week_number in sorted(df['WEEK'].unique()):
#         week_data = df[df['WEEK'] == week_number]
#
#         # Ensure there's data to save for this week
#         if not week_data.empty:
#             # Format the output file name
#             start_date = week_data['DATE_RANGE_START'].min().strftime('%Y-%m-%d')
#             output_file_name = f"week{week_number}__{start_date}_.csv"
#             output_file_path = os.path.join(output_folder_path, output_file_name)
#
#             # Save the weekly data to a new CSV file
#             week_data.to_csv(output_file_path, index=False)
#             print(f'Saved {output_file_name}')
#
# def process_all_files(input_folder_path, output_folder_path):
#     # Ensure the output directory exists
#     if not os.path.exists(output_folder_path):
#         os.makedirs(output_folder_path)
#
#     # Loop through all CSV files in the input directory
#     for file_name in os.listdir(input_folder_path):
#         if file_name.endswith('.csv'):
#             input_file_path = os.path.join(input_folder_path, file_name)
#             print(f'Processing file: {input_file_path}')
#             split_csv_weekly(input_file_path, output_folder_path)
#
# if __name__ == '__main__':
#     process_all_files(input_folder_path, output_folder_path)





# renaming the homepanel files for easier merge of home panel summary with mobility data
# import os
#
# # Specify the directory containing the CSV files
# directory_path = r'D:\Sally_latest\homepanel\weekly'  # Change this to your directory path
#
# # Loop through all files in the directory
# for filename in os.listdir(directory_path):
#     if filename.endswith(".csv"):  # Check if the file is a CSV
#         # Find the position where "2022" starts
#         index = filename.find("2020")
#         if index != -1:  # Make sure "2022" is found in the filename
#             # Remove everything before "2022" and keep the rest
#             new_filename = filename[index:]
#
#             # Remove trailing underscore if present at the end of the filename, before the file extension
#             if new_filename.endswith("_.csv"):
#                 new_filename = new_filename[:-5] + ".csv"  # Replace last 5 characters "_.csv" with ".csv"
#             else:
#                 # If it doesn't end with "_", still make sure it ends with ".csv"
#                 if not new_filename.endswith(".csv"):
#                     new_filename += ".csv"
#
#             # Full path for old and new filenames
#             old_file = os.path.join(directory_path, filename)
#             new_file = os.path.join(directory_path, new_filename)
#             # Rename the file
#             os.rename(old_file, new_file)
#             print(f"Renamed '{filename}' to '{new_filename}'")
#
# print("All files have been renamed.")


# removing .csv extension at the end of the file names.
# import os
#
# # Define the directory containing the files
# directory = r"D:\Hurricane_Ian_Florida\Lee_county\Mobility_popln"
#
# # Loop through the files in the directory
# for filename in os.listdir(directory):
#     # Check if the file ends with ".csv"
#     if filename.endswith(".csv"):
#         # Remove the ".csv" extension from the filename
#         new_name = filename[:-4]
#         # Create the full file paths
#         old_file = os.path.join(directory, filename)
#         new_file = os.path.join(directory, new_name)
#         # Rename the file
#         os.rename(old_file, new_file)
#         print(f"Renamed '{filename}' to '{new_name}'")
#
# print("Renaming complete.")



# Home panel and mobility files were merged based on their names, checking if each week has the same name in both the folders.
# Checking if both the folders have the same filenames.
# import os
# # Paths to the directories
# dir1 = r'D:\Hurricane_Ian_Florida\Lee_county\Mobility_popln'
# dir2 = r'D:\Hurricane_Ian_Florida\Lee_county\Homepanel_Hurricane_Filtered_Weekly'
#
# # Get list of file names in each directory
# files_in_dir1 = set(os.listdir(dir1))
# files_in_dir2 = set(os.listdir(dir2))
#
# # Compare the sets of file names
# if files_in_dir1 == files_in_dir2:
#     print("Both folders have the same files.")
# else:
#     print("The folders do not have the same files.")






'''merging the filtered and cleaned visits data with homepanel data for knowing the number of devices present in the respective block groups'''
# import os
# import pandas as pd
#
# # Define the paths to the directories
# dir1 = r'E:\flood\13May\origin_filtered'
# dir2 = r'E:\flood\Accesories\Flood\Homepanel_Flood_Filtered_Weekly'
# output_dir = r'E:\flood\13May\homepanel_mobility'
#
# # Ensure the output directory exists
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#
# # List all CSV files in each directory
# files1 = {f for f in os.listdir(dir1) if f.endswith('.csv')}
# files2 = {f for f in os.listdir(dir2) if f.endswith('.csv')}
# common_files = files1.intersection(files2)
#
# # Function to clean and normalize DF1 keys
# def clean_df1_keys(col):
#     return col.astype(str).str.replace(r'\.0$', '', regex=True).str.zfill(11)
#
# # Function to clean and normalize DF2 keys
# def clean_df2_keys(col):
#     return col.astype(str).str.lstrip('0').str.zfill(11)
#
# # General function to read a CSV file, clean a specific column using a provided cleaning function
# def read_and_clean(filepath, column_name, cleaner_function):
#     df = pd.read_csv(filepath, dtype={column_name: str})
#     if column_name in df.columns:
#         df[column_name] = cleaner_function(df[column_name])
#         print(f"Cleaned {column_name} in {filepath}: {df[column_name].unique()[:5]}")  # Debug print
#     else:
#         print(f"Column {column_name} not found in {filepath}")
#     return df
#
# # Iterate over the common files and merge them using the cleaned keys
# for file_name in common_files:
#     file_path1 = os.path.join(dir1, file_name)
#     file_path2 = os.path.join(dir2, file_name)
#     df1 = read_and_clean(file_path1, 'visitor_home_cbgs', clean_df1_keys)
#     df2 = read_and_clean(file_path2, 'ORIGIN_BG', clean_df2_keys)
#
#     merged_df = pd.merge(df1, df2, left_on='visitor_home_cbgs', right_on='ORIGIN_BG', how='inner')
#     if not merged_df.empty:
#         output_file = os.path.join(output_dir, file_name)
#         merged_df.to_csv(output_file, index=False)
#         print(f"Data merged successfully for {file_name} and saved to {output_file}")
#     else:
#         print(f"No data merged for {file_name}")
#
# print("Merging completed. Check the console for details.")






'''Normalisation'''
# # # Further, sorting the normalized values according to ORIGIN_BG
# import pandas as pd
# import os
# # Directory containing the input CSV files
# input_dir = r"E:\flood\13May\homepanel_mobility_popln"
# # Directory where the output CSV files will be stored
# output_dir = r"E:\flood\13May\normalisation"
#
# # Make sure output directory exists, if not create it
# if not os.path.exists(output_dir):
#     os.makedirs(output_dir)
#
# # Loop through each file in the input directory
# for filename in os.listdir(input_dir):
#     if filename.endswith(".csv"):
#         # Construct the full file path for reading
#         file_path = os.path.join(input_dir, filename)
#         # Read in the CSV file
#         full_df = pd.read_csv(file_path)
#
#         # Calculate new columns based on the merged DataFrame
#         full_df['scaling_factor'] = full_df['Population_total'] / full_df["NUMBER_DEVICES_RESIDING"]
#         full_df["visitor_scaled"] = full_df["count"] * full_df['scaling_factor']
#         full_df["visits_per_visitor"] = full_df["raw_visit_counts"] / full_df["raw_visitor_counts"]
#         full_df["visit_counts_cbg_scaled"] = full_df["visitor_scaled"] * full_df["visits_per_visitor"]
#
#         # Aggregate data
#         full_df = full_df.groupby(['visitor_home_cbgs']).agg({
#             'visit_counts_cbg_scaled': 'sum',
#             'NUMBER_DEVICES_RESIDING': 'max',
#             'Population_total': 'max',
#             'count': 'max',
#             'visitor_scaled': 'sum',
#             'raw_visit_counts': 'max',
#             'raw_visitor_counts': 'max'
#         }).reset_index()
#
#         # Construct the output file path
#         output_file_path = os.path.join(output_dir,filename)
#         # Save the aggregated data to a new CSV file
#         full_df.to_csv(output_file_path, index=False)
#
#         print(f"Processed and saved: {filename}")






'''adding a column called week and date to track mobility as per the week'''
# import pandas as pd
# import glob
# import os
# import re
# import logging
#
# # Setup logging
# logging.basicConfig(filename='update_csv.log', level=logging.INFO, format='%(asctime)s:%(levelname)s:%(message)s')
#
# # Define the path to the folder containing the CSV files
# folder_path = r'E:\flood\13May\normalisation'
#
# # Use glob to find all CSV files in the folder
# csv_files = glob.glob(os.path.join(folder_path, '*.csv'))
# logging.info(f"Found {len(csv_files)} CSV files in the directory.")
#
# # Define a regular expression to match the specific week number and date pattern in filenames
# week_pattern = re.compile(r'Week-(\d+)', re.IGNORECASE)
# date_pattern = re.compile(r'_(\d{4}-\d{2}-\d{2})\.csv')
#
# # Loop through each file
# for file_path in csv_files:
#     logging.info(f"Processing file: {file_path}")
#     week_match = week_pattern.search(file_path)
#     date_match = date_pattern.search(file_path)
#
#     try:
#         # Read the CSV file
#         df = pd.read_csv(file_path)
#
#         if week_match:
#             week_number = int(week_match.group(1))
#             df['Week'] = week_number  # Add 'Week' column
#             logging.info(f"Added Week number: {week_number}")
#
#         if date_match:
#             date = pd.to_datetime(date_match.group(1))  # Ensure the date column is in datetime format
#             df['Date'] = date  # Add 'Date' column
#             logging.info(f"Added Date: {date}")
#
#         # Save the updated DataFrame to the same file
#         df.to_csv(file_path, index=False)
#         logging.info(f"Updated file saved: {file_path}")
#
#     except Exception as e:
#         logging.error(f"Failed to process file {file_path}: {e}")
#
# logging.info("Week and Date columns added to all files successfully.")





'''Calculating baseline mobility for each CBGs individually'''
# Grouping by CBG and summing up the 'visit_counts_cbg_scaled' for all weeks.
# import pandas as pd
# import os
# import glob
#
# # Setup paths for input and output
# input_folder_path = r'E:\flood\13May\normalisation'
# output_folder_path = r'E:\flood\13May\osorted'
#
# # Ensure the output directory exists
# os.makedirs(output_folder_path, exist_ok=True)
#
# # Using glob to find all CSV files in the directory
# all_files = glob.glob(os.path.join(input_folder_path, "*.csv"))
# all_df = []
#
# # Read each file and append to list
# for filename in all_files:
#     try:
#         df = pd.read_csv(filename, index_col=None, header=0)
#         # Convert origin_bg to string, ensuring no decimal points
#         df['visitor_home_cbgs'] = df['visitor_home_cbgs'].apply(lambda x: f"{int(x)}" if pd.notnull(x) else None)
#         all_df.append(df)
#     except Exception as e:
#         print(f"Failed to read {filename}. Error: {e}")
#
# # Concatenate all data into a single DataFrame
# try:
#     combined_df = pd.concat(all_df, axis=0, ignore_index=True)
# except ValueError:
#     print("No files to concatenate")
#     combined_df = pd.DataFrame()  # Create an empty DataFrame if no files
#
# # Group by "origin_bg" and write to separate files
# if not combined_df.empty:
#     grouped = combined_df.groupby("visitor_home_cbgs")
#     for name, group in grouped:
#         output_filename = f"{name}.csv"
#         group.to_csv(os.path.join(output_folder_path, output_filename), index=False)
#         print(f"File written: {output_filename}")
# else:
#     print("No data to process")
#
# print("All operations completed.")





'''Sorting the rows on the basis of week.'''
# import pandas as pd
# import os
# import glob
# import re  # For regular expression operations
#
# # Define the path to your folder
# folder_path = r'E:\flood\13May\osorted'
#
# # Get a list of all CSV files in the folder
# csv_files = glob.glob(os.path.join(folder_path, "*.csv"))
#
# for file_path in csv_files:
#     # Read the CSV file
#     df = pd.read_csv(file_path)
#
#     # Ensure "Week" column exists
#     if "Week" in df.columns:
#         # Attempt to extract numeric values from the "Week" column
#         df['Week'] = df['Week'].apply(
#             lambda x: int(re.search(r'\d+', str(x)).group()) if re.search(r'\d+', str(x)) else None)
#
#         # Sort the DataFrame by the "Week" column
#         df_sorted = df.sort_values(by=["Week"])
#
#         # Save the sorted DataFrame back to a CSV, overwriting the original file
#         df_sorted.to_csv(file_path, index=False)
#     else:
#         print(f"The file {file_path} does not contain the 'Week' column.")
#
# print("All files have been processed.")





''' for calculating total mobility per county per week'''
# import pandas as pd
# import glob
# import os
#
# def sum_visit_counts(input_directory, output_file_path):
#     # Build the glob pattern to match all CSV files in the input directory
#     file_pattern = os.path.join(input_directory, '*.csv')
#     file_paths = glob.glob(file_pattern)
#
#     # Initialize an empty DataFrame to store summed visit counts
#     summed_visits = pd.DataFrame()
#
#     # Iterate through each file path in the list
#     for file_path in file_paths:
#         # Load the CSV file into a DataFrame
#         data = pd.read_csv(file_path)
#
#         # Ensure that 'Date' is parsed as a date format (if it's not already)
#         # if 'Date' in data.columns:
#         #     data['Date'] = pd.to_datetime(data['Date'])
#
#         # Group by both 'Week' and 'Date' and sum 'visitor_scaled', then reset index to flatten DataFrame
#         group_sum = data.groupby(['Week'])['visit_counts_cbg_scaled'].sum().reset_index()
#
#         # If summed_visits is empty, initialize it with the first file's data
#         if summed_visits.empty:
#             summed_visits = group_sum
#         else:
#             # If not empty, concatenate the new group_sum to it
#             summed_visits = pd.concat([summed_visits, group_sum])
#
#     # After processing all files, group by 'Week' and 'Date' again and sum in case there are overlapping weeks across files
#     final_sum = summed_visits.groupby(['Week'])['visit_counts_cbg_scaled'].sum().reset_index()
#
#     # Save the final summed DataFrame to the specified output file
#     final_sum.to_csv(output_file_path, index=False)
#
#     print(f"Output saved to {output_file_path}")
#
# # Paths for the input directory and output file
# input_directory = r'E:\flood\13May\osorted'
# output_file_path = r'E:\flood\13May\total\total_cbg_per_week_2.csv'
#
# # Execute the function with the specified paths
# sum_visit_counts(input_directory, output_file_path)







'''calculating baseline and  preparedness period mobility and preparedness measuring the preparedness
  flood data for Breathitt county'''
# import pandas as pd
#
# # Load the CSV file
# df = pd.read_csv(r'D:\flood\13May\total\total_cbg_per_week_4.csv')
#
# # Calculate Baseline Period Mobility (Week 1 to Week 21)
# weeks_baseline = list(range(1, 23))
# baseline_mobility_value = df[df['Week'].isin(weeks_baseline)]['visit_counts_cbg_scaled'].median()
#
# # Calculate the maximum of Preparedness Period Mobility (Week 28 and Week 29)
# preparedness_mobility_value = df[df['Week'].isin([28, 29])]['visit_counts_cbg_scaled'].max()
#
# # Add calculated averages as new columns to the DataFrame (these will be the same for all rows)
# df['Base_Mo'] = baseline_mobility_value
# df['Prepared_Mo'] = preparedness_mobility_value
#
# # Calculate Preparedness Measurement for each row and multiply by 100
# df['Measure_Mo'] = ((preparedness_mobility_value - baseline_mobility_value) / baseline_mobility_value) * 100
#
# # Save the updated dataframe to a new CSV file
# df.to_csv(r'D:\flood\13May\total\total_cbg_per_week_4.csv', index=False)
#
# print("The CSV file has been updated with the new columns including Preparedness Measurement.")




'''calculating baseline and  preparedness period mobility and preparedness measuring the preparedness
for sally data for Baldwin county'''
# import pandas as pd
#
# # Load the CSV file
# df = pd.read_csv(r'D:\Sally_latest\baldwin\total_cbg_per_week_2.csv')
#
# # Calculate Baseline Period Mobility (Week 1 to Week 21)
# weeks_baseline = list(range(10, 27))
# baseline_mobility_value = df[df['week'].isin(weeks_baseline)]['visit_counts_cbg_scaled'].median()
#
# # Calculate the maximum of Preparedness Period Mobility (Week 28 and Week 29)
# preparedness_mobility_value = df[df['week'].isin([27, 28])]['visit_counts_cbg_scaled'].max()
#
# # Add calculated averages as new columns to the DataFrame (these will be the same for all rows)
# df['Base_Mo'] = baseline_mobility_value
# df['Prepared_Mo'] = preparedness_mobility_value
#
# # Calculate Preparedness Measurement for each row and multiply by 100
# df['Measure_Mo'] = ((preparedness_mobility_value - baseline_mobility_value) / baseline_mobility_value) * 100
#
# # Save the updated dataframe to a new CSV file
# df.to_csv(r'D:\Sally_latest\baldwin\total_cbg_per_week_4_mo.csv', index=False)
#
# print("The CSV file has been updated with the new columns including Preparedness Measurement.")











'''calculating baseline and  preparedness period mobility and preparedness measuring the preparedness
for hurricane data Ian'''
# import pandas as pd
#
# # Load the CSV file
# df = pd.read_csv(r'D:\Hurricane_Ian_Florida\Lee_county\cbg_scaled\total_cbg_per_week_2.csv')
#
# # Calculate Baseline Period Mobility (Week 1 to Week 21)
# weeks_baseline = list(range(1, 28))
# baseline_mobility_value = df[df['Week'].isin(weeks_baseline)]['visit_counts_cbg_scaled'].median()
#
# # Calculate Preparedness Period Mobility (Week 28 and Week 29)
# preparedness_mobility_value = df[df['Week'].isin([28, 29])]['visit_counts_cbg_scaled'].max()
#
# # Add calculated averages as new columns to the DataFrame (these will be the same for all rows)
# df['Base_Mo'] = baseline_mobility_value
# df['Prepared_Mo'] = preparedness_mobility_value
#
# # Calculate Preparedness Measurement for each row and multiply by 100
# df['Measure_Mo'] = ((preparedness_mobility_value - baseline_mobility_value) / baseline_mobility_value) * 100
#
# # Save the updated dataframe to a new CSV file
# df.to_csv(r'D:\Hurricane_Ian_Florida\Lee_county\cbg_scaled\total_cbg_per_week_2_mo.csv', index=False)
#
# print("The CSV file has been updated with the new columns including Preparedness Measurement.")














'''calculating baseline and  preparedness period mobility and preparedness measuring the preparedness
  flood data for each block groups'''
# import pandas as pd
# import os
#
# # Directory where your CSV files are stored
# directory = r'D:\flood\13May\osorted-27'
#
# # Loop through all CSV files in the specified directory
# for filename in os.listdir(directory):
#     if filename.endswith(".csv"):
#         file_path = os.path.join(directory, filename)
#         print(f"Processing file: {filename}")
#
#         # Read the CSV file
#         df = pd.read_csv(file_path)
#         print("Original columns:", df.columns.tolist())  # Debug: List original columns
#
#         # Ensure the data for weeks 10 to 26 is selected
#         df_weeks_1_to_23 = df.loc[df['Week'].between(1, 24), 'visit_counts_cbg_scaled']
#         # Calculate the median of selected weeks as the baseline
#         baseline = df_weeks_1_to_23.median()
#
#         # Calculate Preparedness (mean of weeks 27 and 28)
#         preparedness = df.loc[df['Week'].between(28, 29), 'visit_counts_cbg_scaled'].max()
#
#         # Calculate the Measure
#         measure = ((preparedness - baseline) / baseline * 100) if baseline != 0 else 0  # Added check to avoid division by zero
#
#         # Add new columns to the dataframe
#         df['BaseMo'] = baseline
#         df['PrepMo'] = preparedness
#         df['MeasureMo'] = measure
#         print("New columns added. Sample data:", df[['BaseMo', 'PrepMo', 'MeasureMo']].head())  # Debug: Check new columns
#
#         # Save the modified dataframe to a new file
#         new_file_path = os.path.join(directory, f"{filename}")
#         df.to_csv(new_file_path, index=False)
#         print(f"Saved processed file as {new_file_path}")
#
# print("All files processed.")






'''calculating baseline and  preparedness period mobility and preparedness measuring the preparedness
 for sally for each block groups'''
# import pandas as pd
# import os
#
# # Directory where your CSV files are stored
# directory = r'D:\\Sally_latest\\normalised-sorted-latest'
#
# # Loop through all CSV files in the specified directory
# for filename in os.listdir(directory):
#     if filename.endswith(".csv"):
#         file_path = os.path.join(directory, filename)
#         print(f"Processing file: {filename}")
#
#         # Read the CSV file
#         df = pd.read_csv(file_path)
#         print("Original columns:", df.columns.tolist())  # Debug: List original columns
#
#         # Ensure the data for weeks 10 to 26 is selected
#         df_weeks_10_to_26 = df.loc[df['week'].between(10, 27), 'visit_counts_cbg_scaled']
#         # Calculate the median of selected weeks as the baseline
#         baseline = df_weeks_10_to_26.median()
#
#         # Calculate Preparedness (mean of weeks 27 and 28)
#         preparedness = df.loc[df['week'].between(27, 28), 'visit_counts_cbg_scaled'].max()
#
#         # Calculate the Measure
#         measure = ((preparedness - baseline) / baseline) *100  if baseline != 0 else 0  # Added check to avoid division by zero
#
#         # Add new columns to the dataframe
#         df['BaseMo'] = baseline
#         df['PrepMo'] = preparedness
#         df['MeasureMo'] = measure
#         print("New columns added. Sample data:", df[['BaseMo', 'PrepMo', 'MeasureMo']].head())  # Debug: Check new columns
#
#         # Save the modified dataframe to a new file
#         new_file_path = os.path.join(directory, f"{filename}")
#         df.to_csv(new_file_path, index=False)
#         print(f"Saved processed file as {new_file_path}")
#
# print("All files processed.")










'''calculating baseline and  preparedness period mobility and preparedness measuring the preparedness
 for sally for each block groups'''
# import pandas as pd
# import os
#
# # Directory where your CSV files are stored
# directory = r'D:\Hurricane_Ian_Florida\Lee\origin_sorted - Copy - Copy'
#
# # Loop through all CSV files in the specified directory
# for filename in os.listdir(directory):
#     if filename.endswith(".csv"):
#         file_path = os.path.join(directory, filename)
#         print(f"Processing file: {filename}")
#
#         # Read the CSV file
#         df = pd.read_csv(file_path)
#         print("Original columns:", df.columns.tolist())  # Debug: List original columns
#
#         # Ensure the data for weeks 10 to 26 is selected
#         df_weeks_10_to_26 = df.loc[df['Week'].between(1, 28), 'visit_counts_cbg_scaled']
#         # Calculate the median of selected weeks as the baseline
#         baseline = df_weeks_10_to_26.median()
#
#         # Calculate Preparedness (mean of weeks 27 and 28)
#         preparedness = df.loc[df['Week'].between(28, 29), 'visit_counts_cbg_scaled'].max()
#
#         # Calculate the Measure
#         measure = ((preparedness - baseline) / baseline) * 100 if baseline != 0 else 0  # Added check to avoid division by zero
#
#         # Add new columns to the dataframe
#         df['BaseMo'] = baseline
#         df['PrepMo'] = preparedness
#         df['MeasureMo'] = measure
#         print("New columns added. Sample data:", df[['BaseMo', 'PrepMo', 'MeasureMo']].head())  # Debug: Check new columns
#
#         # Save the modified dataframe to a new file
#         new_file_path = os.path.join(directory, f"{filename}")
#         df.to_csv(new_file_path, index=False)
#         print(f"Saved processed file as {new_file_path}")
#
# print("All files processed.")



# # # after the process of calculating base and prep
'''Removing any repeated rows of the calculations: 'visitor_home_cbgs', 'BaseMo' ,'PrepMo' ,'MeasureMo
Do this for all the three study counties'''
# import pandas as pd
# import os
#
# # Set the directory containing your CSV files
# directory_path = r'D:\\Sally_latest\\normalised-sorted-latest'
#
# # List all CSV files in the directory
# csv_files = [f for f in os.listdir(directory_path) if f.endswith('.csv')]
#
# # Initialize an empty list to store the data
# data_list = []
#
# # Loop through the files
# for file in csv_files:
#     file_path = os.path.join(directory_path, file)
#
#     # Load the CSV file
#     df = pd.read_csv(file_path)
#
#     # Check if the necessary columns exist in the dataframe
#     if {'visitor_home_cbgs', 'BaseMo', 'PrepMo',
#         'MeasureMo'}.issubset(df.columns):
#         # Select the first value from each specified column (assuming the first row is representative as per your instruction)
#         selected_data = df.loc[0, ['visitor_home_cbgs', 'BaseMo' ,'PrepMo' ,'MeasureMo' ]]
#         data_list.append(selected_data)
#     else:
#         print(f"Missing columns in {file}")
#
# # Concatenate all the data into a single DataFrame
# final_df = pd.concat(data_list, axis=1).transpose()
#
# # Define the output file path
# output_file_path = os.path.join(directory_path, '27_prepmo_mo_sallyy.csv')
#
# # Save the consolidated DataFrame to a new CSV file
# final_df.to_csv(output_file_path, index=False)
#
# print("All files have been processed and the merged file is saved.")




'''cleaning the data by removing any null values'''
# import pandas as pd
#
# # Load the CSV file
# file_path = r'C:\Users\dxapa\OneDrive\Desktop\new\27_prepm.csv'
# df = pd.read_csv(file_path)
#
# # Filter out rows where 'BaseMo' is 0 or NaN
# df_cleaned = df[(df['BaseMo'] != 0) & (df['BaseMo'].notna())]
#
# # Save the updated DataFrame to a new CSV file
# df_cleaned.to_csv(file_path, index=False)
#
# print("Rows with 0 or missing values in 'BaseMo' have been deleted.")





'''t-test'''
# import pandas as pd
# from scipy.stats import ttest_ind
#
# # Load data from CSV files
# df_hurricane_Ian = pd.read_csv(r'C:\Users\dxapa\OneDrive\Desktop\new\27_prepm_Ian.csv')  # Hurricane Ian data CSV file
# df_flood = pd.read_csv(r'C:\Users\dxapa\OneDrive\Desktop\new\27_prepmo_mo_flood.csv')  # Flood data CSV file
# df_hurricane_Sally = pd.read_csv(r'C:\Users\dxapa\OneDrive\Desktop\new\27_prepmo_mo_sallyy.csv')  # Hurricane Sally data CSV file
#
# # Mark the disaster type for each dataframe
# df_hurricane_Ian['Disaster_Type'] = 'Hurricane_Ian'
# df_flood['Disaster_Type'] = 'Flood'
# df_hurricane_Sally['Disaster_Type'] = 'Hurricane_Sally'
#
# # Concatenate the three dataframes
# df = pd.concat([df_hurricane_Ian, df_flood, df_hurricane_Sally], ignore_index=True)
#
# # Calculate skewness and descriptive statistics for each disaster type
# preparedness_hurricane_Ian = df[df['Disaster_Type'] == 'Hurricane_Ian']['MeasureMo'].dropna()
# skewness_Ian = preparedness_hurricane_Ian.skew()
# print(f"Skewness of Hurricane Ian: {skewness_Ian}")
#
# preparedness_flood = df[df['Disaster_Type'] == 'Flood']['MeasureMo'].dropna()
# skewness_flood = preparedness_flood.skew()
# print(f"Skewness of the Flood: {skewness_flood}")
#
# preparedness_hurricane_Sally = df[df['Disaster_Type'] == 'Hurricane_Sally']['MeasureMo'].dropna()
# skewness_Sally = preparedness_hurricane_Sally.skew()
# print(f"Skewness of Hurricane Sally: {skewness_Sally}")
#
# # Display the descriptive statistics
# print("Hurricane Ian Preparedness Measurement:", preparedness_hurricane_Ian.describe())
# print("Hurricane Sally Preparedness Measurement:", preparedness_hurricane_Sally.describe())
# print("Flood Preparedness Measurement:", preparedness_flood.describe())
#
# # Perform t-tests for Preparedness Period Mobility
# t_test_preparedness_hf = ttest_ind(preparedness_hurricane_Ian, preparedness_flood, equal_var=False)
# t_test_preparedness_hs = ttest_ind(preparedness_hurricane_Ian, preparedness_hurricane_Sally, equal_var=False)
# t_test_preparedness_fs = ttest_ind(preparedness_flood, preparedness_hurricane_Sally, equal_var=False)
#
# # Print T-test results
# print("T-test results for Preparedness Period Mobility:")
# print("Hurricane Ian vs. Flood - T-statistic:", t_test_preparedness_hf.statistic, "P-value:", t_test_preparedness_hf.pvalue)
# print("Hurricane Ian vs. Hurricane Sally - T-statistic:", t_test_preparedness_hs.statistic, "P-value:", t_test_preparedness_hs.pvalue)
# print("Flood vs. Hurricane Sally - T-statistic:", t_test_preparedness_fs.statistic, "P-value:", t_test_preparedness_fs.pvalue)







''' graph for flood, Breathitt county'''
# import pandas as pd
# import matplotlib.pyplot as plt
# import numpy as np
# import os
#
# # File path of the CSV file
# file_path = r'D:\flood\13May\total\total_cbg_per_week_4.csv'
#
# # Load the data from CSV
# data = pd.read_csv(file_path)
#
# # Convert columns to numeric and handle NaNs
# data['Week'] = pd.to_numeric(data['Week'], errors='coerce')
# data['visit_counts_cbg_scaled'] = pd.to_numeric(data['visit_counts_cbg_scaled'], errors='coerce')
# data.dropna(subset=['Week', 'visit_counts_cbg_scaled'], inplace=True)
#
# plt.figure(figsize=(12, 8))
# plt.plot(data['Week'].to_numpy(), data['visit_counts_cbg_scaled'].to_numpy(), label='Mobility over the weeks', color='b')
#
# # Adjust y-limits based on the data range plus some padding
# y_min, y_max = data['visit_counts_cbg_scaled'].min(), data['visit_counts_cbg_scaled'].max()
# padding = (y_max - y_min) * 0.1  # Adding 10% padding
# plt.ylim([y_min - padding, y_max + padding])
#
# # Highlight specific weeks
# # Detailed for Week 30
# week_30_data = data[data['Week'] == 30]['visit_counts_cbg_scaled']
# if not week_30_data.empty:
#     week_30_y = week_30_data.iloc[0]
#     plt.scatter(30, week_30_y, color='orange', s=100, edgecolors='k', label='Week 30: Kentucky Flood')
#     plt.text(30 + 1, week_30_y + padding/5, f'{week_30_y:.2f}', verticalalignment='bottom', horizontalalignment='left')
#
# # Minimal for Week 25
# week_25_data = data[data['Week'] == 25]['visit_counts_cbg_scaled']
# if not week_25_data.empty:
#     week_25_y = week_25_data.iloc[0]
#     plt.scatter(25, week_25_y, color='red', s=100, edgecolors='k', label='Week 25: Week of Independence Day')
#
# # Add vertical green lines for weeks 28 and 29 and label them
# plt.axvline(x=28, color='green', linestyle='--', linewidth=2, label='Preparedness Period')
# plt.axvline(x=29, color='green', linestyle='--', linewidth=2)
#
# plt.title('Visit Counts CBG Scaled for Breathitt County by Week')
# plt.xlabel('Week')
# plt.ylabel('Visit Counts CBG Scaled')
#
# # Set x-ticks to display every 2 weeks
# max_week = data['Week'].max()
# plt.xticks(np.arange(0, max_week + 1, 2))  # Adjust step size to 2 weeks
#
# plt.legend()
# plt.grid(True)  # Add grid lines
# plt.savefig(r'C:\Users\dxapa\OneDrive\Desktop\new\mobility-plots\flood3.png', format='png', dpi=300)  # Save in high resolution
# plt.show()




''' graph for sally, Baldwin county'''
# import pandas as pd
# import matplotlib.pyplot as plt
# import numpy as np
#
# # File path of the CSV file
# file_path = r'D:\Sally_latest\baldwin\final_plot_mobility3_processed4.csv'
#
# # Load the data from CSV
# data = pd.read_csv(file_path)
#
# # Convert columns to numeric and handle NaNs
# data['week'] = pd.to_numeric(data['week'], errors='coerce')
# data['visit_counts_cbg_scaled'] = pd.to_numeric(data['visit_counts_cbg_scaled'], errors='coerce')
# data.dropna(subset=['week', 'visit_counts_cbg_scaled'], inplace=True)
#
# plt.figure(figsize=(12, 8))
# plt.plot(data['week'].to_numpy(), data['visit_counts_cbg_scaled'].to_numpy(), label='Mobility over the weeks', color='b')
#
# # Adjust y-limits based on the data range plus some padding
# y_min, y_max = data['visit_counts_cbg_scaled'].min(), data['visit_counts_cbg_scaled'].max()
# padding = (y_max - y_min) * 0.1  # Adding 10% padding
# plt.ylim([y_min - padding, y_max + padding])
#
# # Highlight Week 6 in red without value
# week_6_data = data[data['week'] == 6]
# if not week_6_data.empty:
#     week_6_y = week_6_data['visit_counts_cbg_scaled'].iloc[0]
#     plt.scatter(6, week_6_y, color='red', s=100, edgecolors='k', label='Week 6: COVID-19')
#
# # Highlight Week 29 in orange with value
# week_29_data = data[data['week'] == 29]
# if not week_29_data.empty:
#     week_29_y = week_29_data['visit_counts_cbg_scaled'].iloc[0]
#     plt.scatter(29, week_29_y, color='orange', s=100, edgecolors='k', label='Week 29: Kentucky Flood')
#     plt.text(29 + 1, week_29_y + padding/2, f'{week_29_y:.2f}', verticalalignment='bottom', horizontalalignment='left')
#
# plt.title('Visit Counts CBG Scaled for Baldwin County by Week')
# plt.xlabel('Week')
# plt.ylabel('Visit Counts CBG Scaled')
#
# # Set x-ticks to display every 2 weeks
# max_week = data['week'].max()
# plt.xticks(np.arange(0, max_week + 1, 2))  # Adjust step size to 2 weeks
#
# plt.legend()
# plt.grid(True)
# plt.savefig(r'C:\Users\dxapa\OneDrive\Desktop\new\mobility-plots\\sally1.png', format='png', dpi=300)  # Save in high resolution
# plt.show()







''' graph for Ian, Lee county'''
# import pandas as pd
# import matplotlib.pyplot as plt
# import numpy as np
#
# # File path of the CSV file
# file_path = r'D:\Sally_latest\baldwin\final_plot_mobility3_processed4.csv'
#
# # Load the data from CSV
# data = pd.read_csv(file_path)
#
# # Convert columns to numeric and handle NaNs
# data['week'] = pd.to_numeric(data['week'], errors='coerce')
# data['visit_counts_cbg_scaled'] = pd.to_numeric(data['visit_counts_cbg_scaled'], errors='coerce')
# data.dropna(subset=['week', 'visit_counts_cbg_scaled'], inplace=True)
#
# plt.figure(figsize=(12, 8))
# plt.plot(data['week'].to_numpy(), data['visit_counts_cbg_scaled'].to_numpy(), label='Mobility over the weeks', color='b')
#
# # Adjust y-limits based on the data range plus some padding
# y_min, y_max = data['visit_counts_cbg_scaled'].min(), data['visit_counts_cbg_scaled'].max()
# padding = (y_max - y_min) * 0.1  # Adding 10% padding
# plt.ylim([y_min - padding, y_max + padding])
#
# # Highlight Week 6 in red without value
# week_6_data = data[data['week'] == 6]
# if not week_6_data.empty:
#     week_6_y = week_6_data['visit_counts_cbg_scaled'].iloc[0]
#     plt.scatter(6, week_6_y, color='red', s=100, edgecolors='k', label='Week 6: COVID-19')
#
# # Highlight Week 29 in orange with value
# week_29_data = data[data['week'] == 29]
# if not week_29_data.empty:
#     week_29_y = week_29_data['visit_counts_cbg_scaled'].iloc[0]
#     plt.scatter(29, week_29_y, color='orange', s=100, edgecolors='k', label='Week 29: Hurricane Sally')
#     plt.text(29 + 1, week_29_y + padding/2, f'{week_29_y:.2f}', verticalalignment='bottom', horizontalalignment='left')
#
# # Add vertical green lines for weeks 28 and 29 and label them
# plt.axvline(x=27, color='green', linestyle='--', linewidth=2, label='Preparedness Period')
# plt.axvline(x=28, color='green', linestyle='--', linewidth=2)
#
# plt.title('Visit Counts CBG Scaled for Baldwin County by Week')
# plt.xlabel('Week')
# plt.ylabel('Visit Counts CBG Scaled')
#
# # Set x-ticks to display every 2 weeks
# max_week = data['week'].max()
# plt.xticks(np.arange(0, max_week + 1, 2))  # Adjust step size to 2 weeks
#
# plt.legend()
# plt.grid(True)
# plt.savefig(r'C:\Users\dxapa\OneDrive\Desktop\new\mobility-plots\sally2.png', format='png', dpi=300)  # Save in high resolution
# plt.show()









